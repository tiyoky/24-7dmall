const Discord = require("discord.js")
const { client, config } = require("../index.js")

client.on("ready", () => {

    console.log("|\n|    Advanced tiyokydm\n|   Made by tiyoky\n|\n| Last Update: \n|")

    client.user.setActivity(`tiyoky DM W${config.version}`, { type: "PLAYING" }).catch(console.error);

})